<!DOCTYPE html>
<html>
<head>
    <title>Sukses</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>✅ Keluhan Berhasil Dikirim</h2>
    <p>Terima kasih, keluhan Anda akan segera diproses.</p>
    <a href="complain.php">Kirim Keluhan Lagi</a>
</div>

</body>
</html>
