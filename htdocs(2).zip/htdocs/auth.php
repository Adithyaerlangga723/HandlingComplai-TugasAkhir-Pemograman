<?php
require 'config.php';

if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}
